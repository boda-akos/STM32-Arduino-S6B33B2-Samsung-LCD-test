#ifndef _s6b_H_
#define _s6b_H_
extern void s6b_begin(void);
/*
// Register names
#define s6b_COLADDRSTART_HI    0x02
#define s6b_COLADDRSTART_LO    0x03
#define s6b_COLADDREND_HI      0x04
#define s6b_COLADDREND_LO      0x05
#define s6b_ROWADDRSTART_HI    0x06
#define s6b_ROWADDRSTART_LO    0x07
#define s6b_ROWADDREND_HI      0x08
#define s6b_ROWADDREND_LO      0x09
#define s6b_MEMACCESS          0x16

extern void s6b_setLR(void);

extern void s6b_setAddrWindow(int x1, int y1, int x2, int y2);
extern void s6b_fillScreen(uint16_t color);
extern void s6b_drawPixel(int16_t x, int16_t y, uint16_t color);
extern void s6b_setRotation(uint8_t x);
//extern uint16_t s6b_readPixel(int16_t x, int16_t y);
*/

#endif
